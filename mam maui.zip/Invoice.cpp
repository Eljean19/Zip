#include <iostream>
#include "Invoice.h"
using namespace std;

Invoice::Invoice(string number, string description, int count, float price)
{
	setPartNumber(number);
	setPartDescription(description);
	setQuantity(count);
	setPricePerItem(price);

}

void Invoice::setPartNumber(string number)
{
	partNumber=number;
}

string Invoice::getPartNumber()
{
	return partNumber;
}
void Invoice::setPartDescription(string description)
{
	if (description.length() <= 30) {
		PartDescription = description;
	} else {
		description.resize(30);
		partDescription = description;
	}

}
{
	partDescription=description;
}
string Invoice::getPartDescription()
{
	return partDescription;
}
void Invoice::setQuantity(int count)
{
	if (count>0)
	quantity =count;
	
	if(count<=0)
	{
		quantity =0;
		cout<<"\nValue should not be negative. Enter again\n";
	}
}

int Invoice::getQuantity()
{
	return quantity;
}

void Invoice::setPricePerItem(float price)
{
	if (price>0)
	pricePerItem=price;
	
	if (price<=0)
	{
		pricePerItem=0;
		cout<<"\nPrice cannot be negative."
		<< "\n";
		}
}

float Invoice::getPricePerItem()
{
	return pricePerItem;
}
float Invoice::getInvoiceAmount()
{
	return quantity * pricePerItem;
}
    
