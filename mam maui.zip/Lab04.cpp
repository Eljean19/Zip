#include <iostream>
#include "Invoice.h"
using namespace std;

int main()
{
 string setPartNumber, setPartDescription;
 int  setQuantity;
float setPricePerItem;

	cout << "Part number:";
	cin>>setPartNumber;
	
	cout << "Part Description:";
	cin>>setPartDescription;
	
	cout << "Quantity:";
	cin>>setQuantity;

	cout << "Price per Item: $";
		cin >>setPricePerItem;
	
Invoice invoice( setPartNumber, setPartDescription,setQuantity, setPricePerItem);
	cout << "Part number:" << invoice.getPartNumber() << endl;
	cout << "Part Description:" << invoice.getPartDescription() << endl;
	cout << "Quantity:" << invoice.getQuantity() << endl;
	cout << "Price per Item: $" << invoice.getPricePerItem() << endl;
	cout << "Invoice amount: $" << invoice.getInvoiceAmount() << endl;

	
	return 0;
	
	
}
